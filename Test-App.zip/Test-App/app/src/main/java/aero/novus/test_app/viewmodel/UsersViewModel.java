
package aero.novus.test_app.viewmodel;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.Toast;

import aero.novus.test_app.R;
import aero.novus.test_app.model.User;
import aero.novus.test_app.view.StatActivity;
import me.tatarka.bindingcollectionadapter.ItemView;

import aero.novus.test_app.TestApplication;

import aero.novus.test_app.data.Service;
import aero.novus.test_app.data.UserResponse;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;

import static aero.novus.test_app.BR.user;

public class UsersViewModel  extends BaseObservable {

  public ObservableInt usersProgress;
  public ObservableInt userList;
  public ObservableInt userLabel;
  public ObservableField<String> messageLabel;
  public ObservableArrayList<User> users;
  public final ItemView itemView = ItemView.of(user, R.layout.userlist_item);

  private Context context;
  private Subscription subscription;

  public UsersViewModel(@NonNull Context context) {


    this.context = context;
    usersProgress = new ObservableInt(View.GONE);
    userList = new ObservableInt(View.GONE);
    userLabel = new ObservableInt(View.VISIBLE);
    users=new ObservableArrayList<>();
    messageLabel = new ObservableField<>("load users");
  }

  public void onClickFabLoad(View view) {
    initializeViews();
    fetchPeopleList();
  }public void onClickFabLNext(View view) {

 //navigate to StatActivity

  }

  //It is "public" to show an example of test
  public void initializeViews() {
    userLabel.set(View.GONE);
    userList.set(View.GONE);
    usersProgress.set(View.VISIBLE);
  }

  private void fetchPeopleList() {

    final String URL = "http://api.randomuser.me/?results=15&nat=en";
    unSubscribeFromObservable();
    TestApplication testApplication = TestApplication.create(context);
    Service service = testApplication.getService();
    subscription = service.fetchUser(URL)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(testApplication.subscribeScheduler())
        .subscribe(new Action1<UserResponse>() {
          @Override
          public void call(UserResponse response) {
            usersProgress.set(View.GONE);
            userLabel.set(View.GONE);
            userList.set(View.VISIBLE);
            // your code here

          }
        }, new Action1<Throwable>() {
          @Override
          public void call(Throwable throwable) {
            throwable.printStackTrace();
            messageLabel.set("error");
            usersProgress.set(View.GONE);
            userLabel.set(View.VISIBLE);
            userList.set(View.GONE);
          }
        });
  }

  public void destroy() {
    reset();
  }

  private void unSubscribeFromObservable() {
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
  }

  private void reset() {
    unSubscribeFromObservable();
    subscription = null;
    context = null;

  }
}
