package aero.novus.test_app.model;



public class User {
}
