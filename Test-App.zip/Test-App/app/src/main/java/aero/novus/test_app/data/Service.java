
package aero.novus.test_app.data;


import retrofit2.http.GET;
import retrofit2.http.Url;
import rx.Observable;

public interface Service {
  @GET Observable<UserResponse> fetchUser(@Url String url);
}
