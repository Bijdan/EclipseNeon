

package aero.novus.test_app.view;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import aero.novus.test_app.R;
import aero.novus.test_app.databinding.StatActivityBinding;
import aero.novus.test_app.viewmodel.StatViewModel;


public class StatActivity extends AppCompatActivity  {


  private StatActivityBinding statActivityBinding;
  private StatViewModel statViewModel;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    initDataBinding();


     }

  private void initDataBinding() {

    statActivityBinding = DataBindingUtil.setContentView(this, R.layout.stat_activity);
    statViewModel = new StatViewModel(getContext());
    statActivityBinding.setMainViewModel(statViewModel);

  }


  @Override
  protected void onDestroy() {
    super.onDestroy();
    statViewModel.destroy();
  }


  public Context getContext() {
    return StatActivity.this;
  }


}
