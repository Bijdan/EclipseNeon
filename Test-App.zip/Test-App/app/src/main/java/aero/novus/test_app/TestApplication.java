
package aero.novus.test_app;

import android.content.Context;

import aero.novus.test_app.data.Service;
import aero.novus.test_app.data.ServiceFactory;
import rx.Scheduler;
import rx.schedulers.Schedulers;

public class TestApplication extends android.app.Application {

  private Service service;
  private Scheduler scheduler;

  private static TestApplication get(Context context) {
    return (TestApplication) context.getApplicationContext();
  }

  public static TestApplication create(Context context) {
    return TestApplication.get(context);
  }

  public Service getService() {
    if (service == null) service = ServiceFactory.create();

    return service;
  }

  public Scheduler subscribeScheduler() {
    if (scheduler == null) scheduler = Schedulers.io();

    return scheduler;
  }

  public void setService(Service service) {
    this.service = service;
  }

  public void setScheduler(Scheduler scheduler) {
    this.scheduler = scheduler;
  }
}
