
package aero.novus.test_app.viewmodel;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.ObservableInt;
import android.support.annotation.NonNull;

import java.util.ArrayList;


public class StatViewModel extends BaseObservable {



  public ObservableInt femaleCount = new ObservableInt(0);
  public ObservableInt maleCount = new ObservableInt(0);

  private Context context;


  public StatViewModel(@NonNull Context context) {

       this.context = context;

  }


  public void destroy() {
    reset();
  }



  private void reset() {

    context = null;

  }
}
