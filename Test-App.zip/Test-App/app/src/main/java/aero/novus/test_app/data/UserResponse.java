

package aero.novus.test_app.data;

public class UserResponse {
//response Body
}
