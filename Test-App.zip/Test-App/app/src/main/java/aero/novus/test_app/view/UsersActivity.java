

package aero.novus.test_app.view;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import aero.novus.test_app.R;
import aero.novus.test_app.databinding.UsersActivityBinding;
import aero.novus.test_app.viewmodel.UsersViewModel;

public class UsersActivity extends AppCompatActivity  {

  private UsersActivityBinding usersActivityBinding;
  private UsersViewModel usersViewModel;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    initDataBinding();


     }

  private void initDataBinding() {
    usersActivityBinding = DataBindingUtil.setContentView(this, R.layout.users_activity);
    usersViewModel = new UsersViewModel(getContext());
    usersActivityBinding.setMainViewModel(usersViewModel);

  }


  @Override
  protected void onDestroy() {
    super.onDestroy();
    usersViewModel.destroy();
  }


  public Context getContext() {
    return UsersActivity.this;
  }



}
