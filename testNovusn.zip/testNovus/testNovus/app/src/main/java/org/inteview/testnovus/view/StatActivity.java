package org.inteview.testnovus.view;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class StatActivity extends AppCompatActivity {
}
