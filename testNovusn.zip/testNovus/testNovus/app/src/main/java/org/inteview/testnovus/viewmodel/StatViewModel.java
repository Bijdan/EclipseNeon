package org.inteview.testnovus.viewmodel;

import android.databinding.BaseObservable;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class StatViewModel extends BaseObservable{

}
