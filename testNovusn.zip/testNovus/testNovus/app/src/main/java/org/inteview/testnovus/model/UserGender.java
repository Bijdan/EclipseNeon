package org.inteview.testnovus.model;

/**
 * Created by 3229 on 21/03/2017.
 */

public enum UserGender {
    Male,
    Female
}
