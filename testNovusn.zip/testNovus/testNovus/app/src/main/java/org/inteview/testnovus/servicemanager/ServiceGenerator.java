package org.inteview.testnovus.servicemanager;


import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class ServiceGenerator {
    public static RestAPI create() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://api.randomuser.me/")
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
        return retrofit.create(RestAPI.class);
    }
}
