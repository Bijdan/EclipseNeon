package org.inteview.testnovus.view;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import org.inteview.testnovus.R;
import org.inteview.testnovus.databinding.ActivityUserBinding;
import org.inteview.testnovus.viewmodel.UserViewModel;

public class UserActivity extends AppCompatActivity {

    private ActivityUserBinding userActivityBinding;
    private UserViewModel userViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDataBinding();
    }

    private void initDataBinding() {
        userActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_user);
        userViewModel = new UserViewModel(getContext());
        userActivityBinding.setUserViewModel(userViewModel);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        userViewModel.destroy();
    }


    public Context getContext() {
        return UserActivity.this;
    }
}
