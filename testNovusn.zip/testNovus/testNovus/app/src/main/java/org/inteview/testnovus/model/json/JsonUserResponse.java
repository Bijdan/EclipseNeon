package org.inteview.testnovus.model.json;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class JsonUserResponse {
    private Results[] results;

    private Info info;

    public Results[] getResults() {
        return results;
    }

    public void setResults(Results[] results) {
        this.results = results;
    }

    public Info getInfo() {
        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ClassPojo [results = " + results + ", info = " + info + "]";
    }
}
