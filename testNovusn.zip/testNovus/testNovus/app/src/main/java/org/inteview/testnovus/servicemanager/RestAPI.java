package org.inteview.testnovus.servicemanager;


import org.inteview.testnovus.model.json.JsonUserResponse;

import retrofit2.http.GET;
import retrofit2.http.Url;
import rx.Observable;


/**
 * Created by Nadjib on 20/03/2017.
 */
public interface RestAPI {
    @GET
    Observable<JsonUserResponse> getUser(@Url String url);
}
