package org.inteview.testnovus.viewmodel;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.support.annotation.NonNull;
import android.view.View;

import org.inteview.testnovus.PrimaryApp;
import org.inteview.testnovus.R;
import org.inteview.testnovus.model.User;
import org.inteview.testnovus.model.json.JsonUserResponse;
import org.inteview.testnovus.model.json.Results;
import org.inteview.testnovus.servicemanager.RestAPI;
import org.inteview.testnovus.servicemanager.ServiceGenerator;

import static org.inteview.testnovus.BR.user;
import me.tatarka.bindingcollectionadapter.ItemView;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class UserViewModel extends BaseObservable{
    public ObservableArrayList<User> usersList;
    public final ItemView itemView = ItemView.of(user, R.layout.userlistview_item);

    private Context context;
    private Subscription subscription;

    public UserViewModel(@NonNull Context context) {
        this.context = context;
        usersList=new ObservableArrayList<>();
     }

    public void loadUsers(View view) {
        getUser();
    }

    public void onClickFabLNext(View view) {


    }


    private void getUser() {

        final String URL = "http://api.randomuser.me/?results=5&nat=en";
        unSubscribeFromObservable();
        PrimaryApp testApplication = PrimaryApp.create(context);
        RestAPI service = ServiceGenerator.create();
        subscription = service.getUser(URL)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(testApplication.subscribeScheduler())
                .subscribe(new Action1<JsonUserResponse>() {
                    @Override
                    public void call(JsonUserResponse response) {
                        if(response.getResults()!=null && response.getResults().length!=0){
                    //Fill the user data
                            for (Results result:response.getResults()) {
                                User user = new User(response.getResults()[0].getName().toString(),
                                        response.getResults()[0].getGender());
                                usersList.add(user);
                            }
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        throwable.printStackTrace();
                    }
                });
    }

    public void destroy() {
        reset();
    }

    private void unSubscribeFromObservable() {
        if (subscription != null && !subscription.isUnsubscribed()) {
            subscription.unsubscribe();
        }
    }

    private void reset() {
        unSubscribeFromObservable();
        subscription = null;
        context = null;

    }
}
