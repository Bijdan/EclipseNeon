package org.inteview.testnovus.model;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class User {
    public String Name;
    public UserGender Gender;

    public User(String name, String gender){
        this.Name = name;
        this.Gender = gender=="Male"?UserGender.Male:UserGender.Female;
    }
}
