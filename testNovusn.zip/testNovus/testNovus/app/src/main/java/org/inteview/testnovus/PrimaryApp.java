package org.inteview.testnovus;

import android.content.Context;

import org.inteview.testnovus.servicemanager.RestAPI;
import org.inteview.testnovus.servicemanager.ServiceGenerator;

import rx.Scheduler;
import rx.schedulers.Schedulers;

/**
 * Created by Nadjib on 20/03/2017.
 */
public class PrimaryApp extends  android.app.Application{
    private RestAPI restAPI;
    private Scheduler scheduler;

    private static PrimaryApp get(Context context) {
        return (PrimaryApp) context.getApplicationContext();
    }

    public static PrimaryApp create(Context context) {
        return PrimaryApp.get(context);
    }

    public RestAPI getService() {
        if (restAPI == null) restAPI = ServiceGenerator.create();

        return restAPI;
    }

    public Scheduler subscribeScheduler() {
        if (scheduler == null) scheduler = Schedulers.io();

        return scheduler;
    }

    public void setService(RestAPI service) {
        this.restAPI = service;
    }

    public void setScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
    }
}
